<?php

include('database.config.php');

class database extends mysqli
{
    private static $instance = null;
    private static $user = DBUSER;
    private static $pass = DBPASS;
    private static $dbName = DBNAME;
    private static $dbHost = DBHOST;

    public static function getInstance()
    {
        if (!self::$instance instanceof self) {
            self::$instance = new self;
        }
        return self::$instance;
    }

    private function __construct()
    {
        parent::__construct($this::$dbHost, $this::$user, $this::$pass, $this::$dbName);
        if (mysqli_connect_error()) {
            exit('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
        }
    }

    public function __destruct()
    {
        if (self::$instance && !self::$instance->connect_error)
            self::$instance->close();
    }

    public function dbquery($query)
    {
        if ($this->query($query)) {
            return true;
        } else {
            return $this->error;
        }
    }

    public function get_result($query)
    {
        try {
            $result = $this->query($query);
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                return $row;
            } else return null;
        } catch (Exception $e) {
            $response = new stdClass();
            $response->error = true;
            $response->message = $this->error;

            return $response;
        }
    }
}
